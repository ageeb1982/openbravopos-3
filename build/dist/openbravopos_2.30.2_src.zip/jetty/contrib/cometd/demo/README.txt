
This is a demo of the java servlet for cometd


Simplest thing to do is to run 

  mvn jetty:run-war

and then point TWO different instances of browsers at http://localhost:8080


cheers


